<?
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_fns.php";
include"includes/pg_config.php";
require"includes/pg_protecao.php";
?>
<html>
<head>
<title>Atualizando...</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="refresh" content="1;URL=index2.php?area=inicio">
</head>
<body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table width="100" border="0" align="center" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><table width="100" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td><table width="722" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr> 
                <td><div align="center"><font color="#666699" size="2" face="Tahoma">Atualizando 
                    seus dados...</font></div></td>
              </tr>
              <tr> 
                <td><div align="center"><strong><font size="2" face="Tahoma">Por 
                    favor aguarde.</font></strong></div></td>
              </tr>
              <tr> </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
