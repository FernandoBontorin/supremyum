<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_fns.php";
include"includes/pg_config.php";
require"includes/pg_protecao.php";
//Verifica se o usuario ja esta registrado na tabela perfil
if(mysql_num_rows($sql2)!=1)
{
	mysql_query("INSERT INTO $tabelaPerfil (login,nome,cidade,estado,cep,foto) VALUES ('$loginS','','','','','null')");
	header("Location: atualizaDados.php");
}
//Logout	
if($_GET['acao']=="logout")
{
session_start();
if(session_is_registered('login') AND session_is_registered('senha'))
{
session_destroy();
$m=base64_encode("Voc� n�o est� mais logado!");
header("Location: index.php?erro=ok&m=$m");
exit;
	}
}
//Atualizar dados
if($_GET['acao']=="atualizar")
{
if(empty($_POST['email']))
{
	$m=base64_encode("Preencha um e-mail.");
	header("Location: index2.php?area=mudar&erro=ok&m=$m");
	exit;
}
if($_POST['atual']!=$senhaR)
{
	$m=base64_encode("Senha atual incorreta");
	header("Location: index2.php?area=mudar&erro=ok&m=$m");
	exit;
}
if(!(strpos($_POST['email'],"@")) OR strpos($_POST['email'],"@") != strrpos($_POST['email'],"@"))
{
	$m=base64_encode("Por favor insira um e-mail v�lido.");
	header("Location: index2.php?area=mudar&erro=ok&m=$m");
	exit;
}
if(strlen($_POST['nova'])< 6 || strlen($_POST['confirma'])< 6)
{
	$m=base64_encode("Sua senha deve conter pelo menos 6 caracteres");
	header("Location:index2.php?area=mudar&erro=ok&m=$m");
	exit;
}
if($_POST['nova']!=$_POST['confirma'])
{
	$m=base64_encode("Nova senha e confirma��o n�o s�o iguais");
	header("Location: index2.php?area=mudar&erro=ok&m=$m");
	exit;
}else{
//Retira espa�os em branco no inicio e no final 
//dos campos, retira <> e adiciona barras 
//caso o usuario insira caracteres do tipo ',"
//Pega a data atual
//Pega a hora atual
//Cript. a senha
	$nova=addslashes(strip_tags(trim($_POST['nova'])));
	$nova=base64_encode($_POST['nova']);
	$email=addslashes(strip_tags(trim($_POST['email'])));
	$atualiza=mysql_query("UPDATE $tabela 
							SET senha='$nova',email='$email'
							WHERE login='$loginS' AND senha='$senhaS'
							") or die("Erro ao atualizar dados");
	if($atualiza)
	{
		$m=base64_encode("Dados atualizados com sucesso! Favor efetuar o login novamente");
		header("Location: index.php?erro=ok&m=$m");
		session_start();
			if(session_is_registered('login') AND session_is_registered('senha'))
			{
				session_destroy();
			}
		}
	}	
}
if($_GET['acao']=="atualizarperfil")
{
	$nome	= $_POST['nome'];
	$cidade	= $_POST['cidade'];
	$estado	= $_POST['estado'];
	$cep	= $_POST['cep'];
	if(!(eregi(".JPG",$userfile_name) OR eregi(".GIF",$userfile_name)))
	{
		$m=base64_encode("Arquivos permitidos: .JPG ou .GIF");
		header("Location: index2.php?area=perfil&erro=ok&m=$m");
		exit;
	}
	if($userfile_size>550000) // Valor em bytes (+-537kb)
	{
		$m=base64_encode("Arquivo muito grande, favor escolher outro");
		header("Location: index2.php?area=perfil&erro=ok&m=$m");
		exit;
	}
	if(eregi(".JPG",$userfile_name))
	{
		$fotoGrava=$loginS."_foto.jpeg";
	}
	if(eregi(".GIF",$userfile_name))
	{
		$fotoGrava=$loginS."_foto.gif";
	}
	if(is_uploaded_file($userfile))
	{
	move_uploaded_file($userfile,"./fotos/".$fotoGrava);
	}
	$nome	= ucwords($nome);
	$cidade	= ucwords($cidade);
	$estado	= strtoupper($estado);
	$atualizaP	= mysql_query("UPDATE $tabelaPerfil SET nome='$nome',cidade='$cidade',estado='$estado',cep='$cep',foto='$fotoGrava' WHERE login='$loginS'") OR die("Erro ao inserir dados");
	if($atualizaP)
	{
		echo"<script>javascript:window.location=\"atualizaDados.php\";</script>";
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<link href="estilos.css" rel="stylesheet" type="text/css">

<? pg_Cabecalho("[Voc� est� logado como: $loginR]"); ?>
<body leftmargin="0" rightmargin="0" topmargin="0">
<!-- Come�o da p�gina -->
<? mensagensErro($erro,$m); ?>
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
      <? pg_titulos("Logado",$corDefinida,"[Seja bem vindo, $loginR !]") ?>
    </td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr> 
    <td><table width="650" border="0" cellspacing="0" cellpadding="2">
        <tr> 
          <td> <table width="618" border="0" align="center" cellpadding="3" cellspacing="3">
              <tr> 
                <td width="153" rowspan="2"><div align="center"> 
                    <table width="100" border="0" cellspacing="0" bgcolor="#333333">
                      <tr> 
                        <td><table width="100" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                            <tr> 
                              <td><img src="<? if($foto=="null") { echo "./imagens/no_foto.jpg"; } else{ echo "./fotos/".$foto; } ?>" width="150" height="150"></td>
                            </tr>
                          </table></td>
                      </tr>
                    </table>
                  </div></td>
                <td width="444"> <table width="445" border="0" cellspacing="0" bgcolor="#999999">
                    <tr> 
                      <td><a href="?area=inicio&s=<?=$PHPSESSID?>"><img src="imagens/menu__r1_c1.jpg" width="47" height="30" border="0"></a><a href="?area=perfil&s=<?=$PHPSESSID?>"><img src="imagens/menu__r1_c2.jpg" width="74" height="30" border="0"></a><a href="?area=mudar&s=<?=$PHPSESSID?>"><img src="imagens/menu__r1_c3.jpg" width="80" height="30" border="0"></a><a href="?acao=logout&s=<?=$PHPSESSID?>"><img src="imagens/menu__r1_c4.jpg" width="47" height="30" border="0"></a><img src="imagens/menu__r1_c5.jpg" width="197" height="30"></td>
                    </tr>
                  </table>
                  </td>
              </tr>
              <tr> 
                <td><table width="100" border="0" cellspacing="0" bgcolor="#999999">
                    <tr>
                      <td><table width="100" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
                          <tr>
                            <td><table width="445" border="0" cellpadding="0" cellspacing="0">
                                <tr> 
                                  <td width="345" bgcolor="#F8F8F8"><font size="2" face="Tahoma">&nbsp;&nbsp;<font color="#FF0000" size="1">&#8226;</font> 
                                    Ol&aacute;,<font color="#006699"> <strong> 
                                    <? if(empty($nome)) { echo $loginR; } else {  echo $nome; } ?>
                                    </strong> </font> ! </font></td>
                                </tr>
                                <tr> 
                                  <td>&nbsp;</td>
                                </tr>
                                <tr> 
                                  <td>&nbsp;</td>
                                </tr>
                                <tr> 
                                  <td>&nbsp;</td>
                                </tr>
                                <tr> 
                                  <td>&nbsp;</td>
                                </tr>
                                <tr> 
                                  <td>&nbsp;</td>
                                </tr>
                              </table></td>
                          </tr>
                        </table></td>
                    </tr>
                  </table>
                  
                </td>
              </tr>
            </table> </td>
        </tr>
        <tr> 
          <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
        </tr>
        <tr>
          <td>
            <? 
		  //Meio da p�gina
		  if(empty($area) OR $area=="inicio"){
			include "inicioUsuario.php";
			}elseif($area=="mudar")
			{
			include"mudar.php";
			}elseif($area=="perfil")
			{
			include "perfil.php";
			}else{
			include "inicioUsuario.php";
			}
			?>
          </td>
        </tr>
      </table> </td>
  </tr>
  <tr> 
    <td></td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr>
    <td><center>
        <? direitos($autor,$versao,$emailAutor); ?>
      </center></td>
  </tr>
</table>
<p> 
  <!--Fim da p�gina -->
</p>
</body>
</html>
