<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
if($acao=="apagaInstalacao")
{
	if(file_exists("instala.php"))
	{
		@unlink("instala.php");
		echo"<script>javascript:window.location=\"index.php\";alert('Apagado com sucesso!');</script>";
	}
}
include"includes/pg_config.php";
$instala = mysql_query("
CREATE TABLE $tabela (
  id int(255) NOT NULL auto_increment,
  login varchar(200) NOT NULL default '',
  senha varchar(200) NOT NULL default '',
  email varchar(200) NOT NULL default '',
  data varchar(10) NOT NULL default '',
  hora varchar(10) NOT NULL default '',
  PRIMARY KEY (id)
) TYPE=MyISAM;") or die("Erro ao criar a tabela: $tabela <br>".mysql_error());
$instala2=mysql_query("
CREATE TABLE $tabelaPerfil (
	login varchar(255) NOT NULL,
	nome varchar(255) NOT NULL,
	cidade varchar(255) NOT NULL,
	estado varchar(5) NOT NULL,
	cep varchar(30) NOT NULL,
	foto varchar(255) NOT NULL default'null',
	PRIMARY KEY( login )
)TYPE=MyISAM;") or die("Erro ao criar tabela: $tabelaPerfil <br>".mysql_error());
$insertTest=mysql_query("INSERT INTO $tabela (id,login,senha,email,data,hora) VALUES ('','teste','dGVzdGU=','stuart.eduardo@gmail.com','26/10/2006','14:04:23')");
$insertTestPerfil=mysql_query("INSERT INTO $tabelaPerfil (`login`, `nome`, `cidade`, `estado`, `cep`, `foto`) VALUES ('teste', 'testando sistema', 'teste', 'XX', '123456789', 'teste_foto.jpeg')");
if($instala)
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Instalado com sucesso!</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="estilos.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="547" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><p><font color="#333333" size="6" face="Verdana, Arial, Helvetica, sans-serif"><strong>Instalado 
        com sucesso!</strong></font></p>
      <p>&nbsp;</p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Para que 
        o sistema funcione corretamente,</font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong><font color="#FF0000">Apagar</font></strong> 
        esse arquivo (instala.php), ap&oacute;s efetuar a instala&ccedil;&atilde;o.</font></p>
      <p><font size="2" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font><font size="2">[<font face="Verdana, Arial, Helvetica, sans-serif"><a href="?acao=apagaInstalacao">Clique 
        aqui para apagar o arquivo</a></font>] </font></p></td>
  </tr>
  <tr> </tr>
  <tr>
    <td><div align="center"><br>
        <a href="http://www.stu.1br.net" target="_blank"><img src="by.gif" width="450" height="100" border="0"></a><br>
      </div></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</body>
</html>
<? 
}else{ 
echo"<font face=\"Tahoma\" size=\"2\">";
echo"<u>Erro</u>: Ocorreu um erro ao criar instalar o sistema.<br>";
echo"Verifique se o arquivo: pg_config (includes/pg_config.php) foi configurado corretamente";
echo"</font>";
} 
?>