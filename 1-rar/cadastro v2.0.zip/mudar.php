<?
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_protecao.php";
?>
<table width="645" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td bgcolor="#F8F8F8"><font color="#FF9900" size="2" face="Tahoma"><strong>Todos 
      os campos s&atilde;o obrigat&oacute;rios</strong></font></td>
  </tr>
</table>
<table width="645" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><form action="<?=$PHP_SELF?>?area=mudar&acao=atualizar" method="post" name="formatualiza" id="formatualiza">
        <table width="645" border="0" cellspacing="0" cellpadding="2">
          <tr> 
            <td width="264"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Login:</font></div></td>
            <td width="373"><input name="loginmostra" type="text" disabled class="inputs" id="loginmostra" value="<?=$loginR?>" size="35"> 
            </td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">E-mail:</font></div></td>
            <td><input name="email" type="text" class="inputs" id="email" value="<?=$emailR?>" size="45"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Senha 
                Atual:</font></div></td>
            <td><input name="atual" type="password" class="inputs" id="atual" size="20"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nova 
                Senha:</font></div></td>
            <td><input name="nova" type="password" class="inputs" id="nova" size="20"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Confirmar:</font></div></td>
            <td><input name="confirma" type="password" class="inputs" id="confirma" size="20"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Data 
                de registro:</font></div></td>
            <td><input name="datamostra" type="text" class="inputs" id="datamostra" value="<?=$dataR?>" disabled></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Hora 
                de registro:</font></div></td>
            <td><input name="horamostra" type="text" class="inputs" id="horamostra" value="<?=$horaR?>" disabled></td>
          </tr>
          <tr> 
            <td>&nbsp; </td>
            <td><input type="submit" name="Submit" value="Atualizar dados" class="botao"></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
