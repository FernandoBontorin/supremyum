<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"../includes/pg_config.php";
include"protAdmin.php"; 
//A��es 
if($_GET['acao']=="apagar")
{
session_start();
if(session_is_registered('adminL') AND session_is_registered('adminP'))
{
	$deleta=mysql_query("DELETE  FROM $tabela WHERE id='$id'") or die("Erro ao deletar");
}
if($deleta)
{
	header("Location: index2.php?erro=ok&area=usuarios&pagina=$pagina&m=Apagado com sucesso");
}}
if($_GET['acao']=="logout")
{
	session_start();
	if(session_is_registered('adminL') AND session_is_registered('adminP'))
	{
		session_destroy();
		header("Location: index.php?erro=ok&m=Voc� efetuou o logout.");
		exit;
	}
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[Admin]</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../estilos.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" rightmargin="0" topmargin="0">
<table width="356" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td>
      <?
	if($erro=="ok")
	{
		echo"<script>javascript:alert('".$m."');</script>";
	}	
	?>
    </td>
  </tr>
  <tr> 
    <td><font size="5" face="Verdana, Arial, Helvetica, sans-serif"><strong>Logado<br>
      </strong></font> <hr size="1" color="#CCCCCC" style="border:dotted;" noshade> 
    </td>
  </tr>
  <tr> 
    <td bgcolor="#DCDCED"><table width="349" border="0" align="center" cellpadding="2" cellspacing="2">
        <tr bgcolor="#FFFFFF"> 
          <td width="116"><div align="center"><a href="?area=inicio"><font size="2" face="Tahoma">Inicio</font></a></div></td>
          <td width="116"><div align="center"><font size="2" face="Tahoma"><a href="?area=usuarios">Usu&aacute;rios</a></font></div></td>
          <td width="116"><div align="center"><font size="2" face="Tahoma"><a href="?acao=logout">Logout</a></font></div></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><table width="343" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr> 
          <td> 
            <?
		  if(empty($area) OR $area=="inicio")
		  {  
		  ?>
          </td>
        </tr>
        <tr> 
          <td><font size="1" face="Tahoma"><br>
            Total de usu&aacute;rios registrados:<strong><font color="#FF0000"> 
            <?=$total?>
            </font> . <br>
            </strong> </font></td>
        </tr>
        <tr>
          <td><? }elseif($area=="usuarios"){ include"usuarios.php"; }else{ echo"<font face=\"Tahoma\" size=\"1\">Escolha uma op��o no menu</font>"; }  ?></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><div align="center">
        <hr size="1" color="#CCCCCC" style="border:dotted;" noshade>
      </div></td>
  </tr>
  <tr> 
    <td><div align="center"><font size="1" face="Tahoma">Criado por <a href="mailto:stuart.eduardo@gmail.com">Eduardo 
        Stuart</a></font></div></td>
  </tr>
  <tr>
    <td><div align="center"><font size="1" face="Tahoma"><a href="http://www.stu.1br.net" target="_blank">http://www.stu.1br.net</a></font></div></td>
  </tr>
</table>
</body>
</html>
