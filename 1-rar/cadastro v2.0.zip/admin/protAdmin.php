<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
session_start();
if(!(session_is_registered('adminL') AND session_is_registered('adminP')))
{
?> 
<table width="428" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><div align="center"><font color="#FF0000" size="7" face="Verdana, Arial, Helvetica, sans-serif"><strong>Acesso 
        negado!</strong></font></div></td>
  </tr>
  <tr>
    <td><div align="center"><font size="1" face="Geneva, Arial, Helvetica, sans-serif"><strong>Favor 
        efetuar o login</strong></font></div></td>
  </tr>
</table>
<?
exit;
}else{
$select=mysql_query("SELECT login FROM $tabela");
$total=mysql_num_rows($select);
}
?>