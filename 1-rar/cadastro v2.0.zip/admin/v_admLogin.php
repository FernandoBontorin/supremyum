<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"../includes/pg_config.php";
if($_GET['acao']=="logar")
{
	if(!(empty($_POST['adminL']) && empty($_POST['adminS'])))
	{
		if($_POST['adminL']!=$adminLogin || $_POST['adminS']!=$adminSenha)
	{
			header("Location: index.php?erro=ok&m=Erro - Dados inv�lidos");
			exit;
	}
		if($_POST['adminL']==$adminLogin && $_POST['adminS']==$adminSenha)
	{
			session_start();
			if(session_is_registered('adminL') AND session_is_registered('adminP'))
			{
				session_destroy();
			}
			$adminP=md5($adminS);
			session_start();
			session_register('adminL');
			session_register('adminP');
			header("Location: index2.php");
			exit;
		}
	}else{
		header("Location: index.php?erro=ok&m=Campos em branco");
		exit;
	}
}
?>