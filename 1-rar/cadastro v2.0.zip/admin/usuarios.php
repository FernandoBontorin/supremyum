<?
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
 include"protAdmin.php";
?> <br> 
<table width="352" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> </tr>
  <tr> </tr>
  <tr> 
    <td><font size="1" face="Tahoma"> 
      <?
require_once"../includes/pg_config.php";
if(!$pagina)
{
	$pagina=1;
}
$pRegistro=($pagina*$pPagina)-$pPagina;
$selecionaD=mysql_query("SELECT * FROM $tabela ORDER BY login LIMIT $pRegistro,$pPagina");
$sql=mysql_query("SELECT * FROM $tabela");
$total=mysql_num_rows($sql); 
if(mysql_num_rows($sql)>"0")
{
while($dados=mysql_fetch_array($selecionaD))
{
$idR=$dados['id'];
$loginR=$dados['login'];
$emailR=$dados['email'];
?>
      </font></td>
  </tr>
  <tr> 
    <td> <table width="100" border="0" cellspacing="0" bgcolor="#CCCCCC">
        <tr>
          <td><table width="100" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
              <tr>
                <td><table width="352" border="0" cellspacing="0" cellpadding="2">
                    <tr> 
                      <td colspan="2" bgcolor="#F8F8F8"><font size="1" face="Tahoma">ID: [ <font color="#666699"><strong> 
                        <?=$dados['id'];?>
                        </strong> </font> ]</font><font size="1" face="Tahoma">&nbsp;</font></td>
                      <td width="3" bgcolor="#f8f8f8">&nbsp;</td>
                    </tr>
                    <tr> 
                      <td width="55"><font size="1" face="Tahoma">&nbsp;</font></td>
                      <td width="282"><font size="1" face="Tahoma">Login: <strong><font color="#6633CC"> 
                        <?=$dados['login'];?>
                        </font></strong> </font></td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr bgcolor="#F8F8F8"> 
                      <td><font size="1" face="Tahoma">&nbsp;</font></td>
                      <td><font size="1" face="Tahoma">Email: <a href="mailto:<?=$dados['email'];?>"> 
                        <?=$dados['email'];?>
                        </a> </font></td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr> 
                      <td colspan="2"><a href="?area=usuarios&acao=apagar&id=<?=$idR?>&pagina=<?=$pagina?>"><font color="#FF0000" size="2" face="Tahoma">Apagar 
                        usuario?</font></a></td>
                      <td>&nbsp;</td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
        </tr>
      </table>
      <br>
       </td>
  </tr>
  <tr>
    <td><div align="center"><font size="1" face="Tahoma"> 
        <? 
	 }
$selecionaD=mysql_query("SELECT COUNT(*) FROM $tabela");
list($usuariosTotal)=mysql_fetch_array($selecionaD);
$total_paginas	=	$usuariosTotal/$pPagina;
$anteP=$pagina-1;
$proxP=$pagina+1;
if($pagina>1)
{
$anteP_link="<a href=\"$PHP_SELF?area=usuarios&pagina=$anteP\">Anterior</a>";
}else{
$anteP_link="Anterior";
}
if($total_paginas>$pagina)
{
$proxP_link="<a href=\"$PHP_SELF?area=usuarios&pagina=$proxP\">Proxima</a>";
}else{
$proxP_link="Proxima";
}
$total_paginas=ceil($total_paginas);
$naveg="";
for($x=1;$x<=$total_paginas;$x++)
{
if($x==$pagina)
{
$naveg.="[$x]";
}else{
$naveg.="<a href=\"$PHP_SELF?area=usuarios&pagina=$x\">[$x]</a>";
}}
echo "$anteP_link | $naveg | $proxP_link"; 
}else{ echo"<font face=\"Tahoma\" size=\"1\">Nenhum usu�rio registrado.</font>"; }
?>
        </font></div></td>
  </tr>
</table>
