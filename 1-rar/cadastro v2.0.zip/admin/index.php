<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"../includes/pg_config.php";
require"v_admLogin.php";
session_start();
if(session_is_registered('adminL') AND session_is_registered('adminP'))
{
session_destroy();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[Admin]</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../estilos.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" rightmargin="0" topmargin="0">
<table width="356" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><?
	if($erro=="ok")
	{
		echo"<script>javascript:alert('".$m."');</script>";
	}	
	?></td>
  </tr>
  <tr> 
    <td><font size="5" face="Verdana, Arial, Helvetica, sans-serif"><strong>Login 
      admin <br>
      </strong></font> <hr size="1" color="#CCCCCC" style="border:dotted;" noshade> 
    </td>
  </tr>
  <tr> 
    <td><form name="formlogin" method="post" action="<?=$PHP_SELF?>?acao=logar">
        <table width="297" border="0" align="center" cellpadding="3" cellspacing="0">
          <tr> 
            <td width="87"><div align="right"><font size="1" face="Tahoma">Login:</font></div></td>
            <td width="198"><input name="adminL" type="text" class="inputs" id="adminL"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Tahoma">Senha:</font></div></td>
            <td><input name="adminS" type="password" class="inputs" id="adminS"></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input name="Submit" type="submit" class="botao" value="Logar"></td>
          </tr>
        </table>
      </form></td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" style="border:dotted;" noshade></td>
  </tr>
  <tr> 
    <td><div align="center"><font size="1" face="Tahoma">Criado por <a href="mailto:stuart.eduardo@gmail.com">Eduardo 
        Stuart</a></font></div></td>
  </tr>
  <tr>
    <td><div align="center"><font size="1" face="Tahoma"><a href="http://www.stu.1br.net" target="_blank">http://www.stu.1br.net</a></font></div></td>
  </tr>
</table>
</body>
</html>
