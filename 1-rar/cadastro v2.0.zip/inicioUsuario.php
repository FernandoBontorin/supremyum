<?
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
require"includes/pg_protecao.php";
?>
<font size="2" face="Tahoma"><strong>Adicione aqui o conteudo inicial para a p&aacute;gina do 
usuario (Painel do usuario)</strong></font>