<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_fns.php";
include"includes/pg_config.php";
/*******************************************************************
*
*	Opcao para lembrar senha
*
********************************************************************/
if($_GET['acao']=="lembrar")
{
if(!empty($_POST['login']))
{
	lembrarSenha($login);
}else{
	$m=	"Voc� n�o digitou o login";
	$m=	base64_encode($m);
	header("Location: lembrar.php?erro=ok&m=$m");
	exit;
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<link href="estilos.css" rel="stylesheet" type="text/css">
<? pg_Cabecalho("[Lembrar senha]"); ?>
</head>
<body leftmargin="0" rightmargin="0" topmargin="0">
<!-- Come�o da p�gina -->
<? mensagensErro($erro,$m); ?>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
      <? pg_titulos("Lembrar senha",$corDefinida,"[Sua senha ser� enviada para o seu e-mail]") ?>
      <br>
       <? menuOpcoes("index.php","[Efetuar o login]","cadastro.php","[Cadastrar]"); ?> </td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr> 
    <td><table width="308" border="0" align="center" cellpadding="3" cellspacing="0">
        <tr>
          <td>
<form action="<?=$PHP_SELF?>?acao=lembrar" method="post" name="formlembrar" id="formlembrar">
              <div align="center"><font size="1" face="Tahoma">Digite o seu login:</font> 
                <input name="login" type="text" class="inputs" id="login">
                <input type="submit" name="Submit" value="ok" class="botao">
              </div>
            </form></td>
        </tr>
      </table></td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr>
    <td><div align="center">
        <? direitos($autor,$versao,$emailAutor); ?>
      </div></td>
  </tr>
</table>

  <!--Fim da p�gina -->

</body>
</html>
