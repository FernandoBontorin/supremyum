<?
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_protecao.php";
?>
<div align="center">
  <table width="645" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td bgcolor="#F8F8F8"><strong><font color="#FF9900" size="2" face="Tahoma">Campos 
        opcionais</font></strong></td>
    </tr>
  </table>
  
</div>
<table width="332" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><form action="<?=$PHP_SELF?>?area=perfil&acao=atualizarperfil" method="post" enctype="multipart/form-data" name="formatualiza" id="formatualiza">
        <table width="645" border="0" cellspacing="0" cellpadding="2">
          <tr> 
            <td width="250"><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nome:</font></div></td>
            <td width="387"><input name="nome" type="text"  class="inputs" id="nome" value="<?=$nome?>" size="35" maxlength="50"> 
            </td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cidade:</font></div></td>
            <td><input name="cidade" type="text" class="inputs" id="cidade" value="<?=$cidade?>" size="45" maxlength="50"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Estado</font></div></td>
            <td><input name="estado" type="text" class="inputs" id="estado" value="<?=$estado?>" size="5" maxlength="5"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">CEP:</font></div></td>
            <td><input name="cep" type="text" class="inputs" id="cep" value="<?=$cep?>" size="20" maxlength="25"></td>
          </tr>
          <tr> 
            <td><div align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Foto:</font></div></td>
            <td> <input name="userfile" type="file" class="inputs" id="userfile"></td>
          </tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input type="submit" name="Submit" value="Atualizar perfil" class="botao"></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
