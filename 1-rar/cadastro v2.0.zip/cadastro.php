<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
include"includes/pg_fns.php";
include"includes/pg_config.php";
//Gera um c�digo randomico
srand((double)microtime()*1000000); 
$codigo_aleatorio=rand(1000, 5000); 
//Registra novo usu�rio
if($_GET['acao']=="registrausuario")
{
//Verifica o c�digo
if(!empty($_POST['codigo']))
{
if($_POST['codigo']==$_POST['codigo_correto'])
{
	registraNovo($c_login,$c_senha,$c_email);
}else{
	$m=base64_encode("C�digo incorreto");
	$c_email=base64_encode($c_email);
	$c_login=base64_encode($c_login);
	header("Location: cadastro.php?erro=ok&m=$m&l=$c_login&e=$c_email");		
}
}else{
	$m=base64_encode("Voc� n�o digitou o c�digo");
	$c_email=base64_encode($c_email);
	$c_login=base64_encode($c_login);
	header("Location: cadastro.php?erro=ok&m=$m&l=$c_login&e=$c_email");
	}
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<link href="estilos.css" rel="stylesheet" type="text/css">
<? pg_Cabecalho("[Cadastro de usu�rios]"); ?>
</head>
<body leftmargin="0" rightmargin="0" topmargin="0">
<!-- Come�o da p�gina -->
<? mensagensErro($erro,$m); ?>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
      <? pg_titulos("Cadastro de usu�rios",$corDefinida,"[Preencha os campos abaixo para efetuar o cadastro]") ?>
      <br>
       <? menuOpcoes("index.php","[Efetuar o login]","lembrar.php","[Lembrar senha]"); ?> </td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr> 
    <td><center>
        <? formCadastro($codigo_aleatorio,$l,$e); ?>
      </center></td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr>
    <td><div align="center">
        <? direitos($autor,$versao,$emailAutor); ?>
      </div></td>
  </tr>
</table>

  <!--Fim da p�gina -->

</body>
</html>
