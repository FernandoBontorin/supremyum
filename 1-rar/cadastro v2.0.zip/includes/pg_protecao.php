<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
session_start();
if(!(session_is_registered('login') AND session_is_registered('senha')))
{
?>
<link href="estilos.css" rel="stylesheet" type="text/css">

<table width="485" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td><div align="center"><font color="#FF0000" size="7" face="Verdana, Arial, Helvetica, sans-serif"><strong><img src="imagens/acess_negado.gif" width="36" height="34">Acesso 
        negado!</strong> </font></div></td>
  </tr>
  <tr> 
    <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Clique 
        <a href="index.php">aqui</a> para efetuar o login </font></div></td>
  </tr>
  <tr> 
    <td><div align="center"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">[<a href="cadastro.php">Cadastrar</a>]</font></div></td>
  </tr>
</table>
<? 
exit;
}else{
$loginS=$HTTP_SESSION_VARS['login'];//Pega o login da sess�o registrada
$senhaS=$HTTP_SESSION_VARS['senha'];//Pega a senha da sess�o registrada
$sql=mysql_query("SELECT * FROM $tabela WHERE login='$loginS' AND senha='$senhaS'");
$sql2=mysql_query("SELECT * FROM $tabelaPerfil WHERE login='$loginS'");
$dados=mysql_fetch_array($sql);
//Dados registrados
$emailR=$dados['email'];
$dataR=$dados['data'];
$horaR=$dados['hora'];
$loginR=$dados['login'];
$senhaR=$dados['senha'];
$senhaR=base64_decode($senhaR);
$idR=$dados['id'];
$perfil=mysql_fetch_array($sql2);
$loginPerfil=$perfil['login'];
$nome=$perfil['nome'];
$cidade=$perfil['cidade'];
$estado=$perfil['estado'];
$cep=$perfil['cep'];
$foto=$perfil['foto'];
}
?>