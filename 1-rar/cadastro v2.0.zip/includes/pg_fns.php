<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
//Verifica se o arquivo de instala��o foi apagado
function instalaVerifica($acao)
{
if(file_exists("instala.php"))
{ 
	if($acao=="apagaInstala")
	{
	@unlink("instala.php");
	echo"<script>javascript:window.location=\"index.php\";alert('Apagado com sucesso!');</script>";
	}
	echo"<br><br>";
	echo"<center><font face=\"Tahoma\" size=\"2\" color=\"RED\">";
	echo"<u>Erro</u>: O arquivo de instala��o ( instala.php ) ainda existe. Por favor delete o arquivo, para continuar usando o sistema.";
	echo"<br><a href=\"?acao=apagaInstala\">Clique aqui para deletar o arquivo</a></font></center>\n";
	echo"</html>";
	exit; 
	}
}
//Cabe�alho das p�ginas
function pg_Cabecalho($titulo) 
{
	global $keywords,$description;
	echo"<head>\n";
	echo"<title>$titulo</title>\n";
	echo"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n";
	echo"<meta name=\"keywords\" content=\"$keywords\">\n";
	echo"<meta name=\"description\" content=\"$description\">\n";
}
//Subtitulos
function pg_titulos($subtitulo,$cor,$msgSub)
{
	echo"<font size=\"5\" face=\"Geneva, Arial, Helvetica, sans-serif\" color=\"$cor\"><strong>\n";
	echo"$subtitulo\n";
	echo"</strong></font>\n";
	echo"<br><font size=\"1\" face=\"Tahoma\">\n";
	echo"$msgSub\n";
	echo"</strong>\n";
}
//Menu
function menuOpcoes($linkA,$mostraA,$linkB,$mostraB)
{
	echo"<br><font size=\"1\" face=\"Tahoma\">\n";
	echo"<a href=\"$linkA\" title=\"$mostraA\">$mostraA</a>\n";
	echo"<a href=\"$linkB\" title=\"$mostraB\">$mostraB</a>\n";
	echo"</font>";
}	
//Mensagens de erro
function mensagensErro($erro,$m) 
{
	if($erro=="ok")
	{
		$m=base64_decode($m);
		echo"<script>javascript:alert('".$m."');</script>";
	}
}
//Formulario de cadastro
function formCadastro($codigo_aleatorio,$l,$e)
{
	$l=base64_decode($l);
	$e=base64_decode($e);
	echo"<br><table width=\"100\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	<tr>
	<td><form action=\"?acao=registrausuario\" method=\"post\" name=\"formcadastro\" id=\"formcadastro\">
	<table width=\"306\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">
	<tr> 
	<td><div align=\"right\"><strong><font size=\"1\" face=\"Geneva, Arial, Helvetica, sans-serif\">Login:</font></strong></div></td>
	<td> <input name=\"c_login\" type=\"text\" id=\"c_login\" class=\"inputs\" value=\"$l\"> </td>
	</tr>
	<tr> 
	<td><div align=\"right\"><strong><font size=\"1\" face=\"Geneva, Arial, Helvetica, sans-serif\">Senha:</font></strong></div></td>
	<td><input name=\"c_senha\" type=\"password\" id=\"c_senha\" class=\"inputs\"></td>
	</tr>
	<tr> 
	<td><div align=\"right\"><strong><font size=\"1\" face=\"Geneva, Arial, Helvetica, sans-serif\">E-mail:</font></strong></div></td>
	<td><input name=\"c_email\" type=\"text\" id=\"c_email\" class=\"inputs\" value=\"$e\"></td>
	</tr>
	<tr> 
	<td><div align=\"right\"><strong><font size=\"1\" face=\"Geneva, Arial, Helvetica, sans-serif\">C&oacute;digo:</font></strong></div></td>
	<td><font color=\"#6633CC\" size=\"2\" face=\"Tahoma\"><strong>$codigo_aleatorio</strong></font> 
    <input name=\"codigo\" type=\"text\" id=\"codigo\" size=\"4\" maxlength=\"4\" class=\"inputs\"></td>
	</tr>
	<tr> 
	<td><input name=\"codigo_correto\" type=\"hidden\" id=\"codigo_correto\" value=\"$codigo_aleatorio\"></td>
	<td><input name=\"bt1\" type=\"submit\" class=\"botao\" id=\"bt1\" value=\"Cadastrar\"> <input name=\"bt2\" type=\"reset\" class=\"botao\" id=\"bt2\" value=\"Limpar\"></td>
	</tr>
	</table>
	</form></td>
	</tr>
	</table>
	";
}
//Registra novo usu�rio
function registraNovo($c_login,$c_senha,$c_email)
{
global $tabela,$tabelaPerfil;
//Verifica e-mail
	if (!(strpos($_POST['c_email'],"@")) OR strpos($_POST['c_email'],"@") != strrpos($_POST['c_email'],"@"))
	{	
		$c_login =base64_encode($c_login);
		$c_email=base64_encode($c_email);
		$m=base64_encode("Por favor, insira um e-mail v�lido");
		header("Location: cadastro.php?erro=ok&m=$m&l=$c_login");
		exit;
	}
//Verifica o tamanho da senha e do login
	if(strlen($_POST['c_senha']) < 6)
	{
		$c_login =base64_encode($c_login);
		$c_email=base64_encode($c_email);
		$m=base64_encode("Sua senha deve conter pelo menos 6 caracteres");
		header("Location: cadastro.php?erro=ok&m=$m&l=$c_login&e=$c_email");
		exit;
	}
	if(strlen($_POST['c_login']) < 3){
		$c_login =base64_encode($c_login);
		$c_email=base64_encode($c_email);
		$m=base64_encode("Seu login deve conter pelo menos 3 caracteres");
		header("Location: cadastro.php?erro=ok&m=$m&e=$c_email");
		exit;
	}
//Verifica se o usu�rio j� existe
	$sql=mysql_query("SELECT login FROM $tabela WHERE login='$c_login'");
	if(mysql_num_rows($sql)>0)
	{
		$c_login=base64_encode($c_login);
		$c_email=base64_encode($c_email);
		$m=base64_encode("Por favor insira outro login, esse j� est� sendo utilizado");
		header("Location: cadastro.php?erro=ok&m=$m&l=$c_login&e=$c_email");
		exit;
	}else{
//Retira espa�os em branco no inicio e no final 
//dos campos, retira <> e adiciona barras 
//caso o usuario insira caracteres do tipo ',"
//Pega a data atual
//Pega a hora atual
//Cript. a senha
	$c_login= addslashes(strip_tags(trim($_POST['c_login'])));
	$c_senha= addslashes(strip_tags(trim($_POST['c_senha'])));
	$c_senha= base64_encode($_POST['c_senha']);
	$c_email= addslashes(strip_tags(trim($_POST['c_email'])));
	$data	= date("d/m/Y");
	$hora	= date("H:i:s");
	$m=base64_encode("Registrado com sucesso.");
	header("Location: index.php?erro=ok&m=$m");
	mysql_query("
	INSERT INTO $tabela 
	(id,login,senha,email,data,hora) VALUES ('','$c_login','$c_senha','$c_email','$data','$hora')
	") OR die("Erro ao inserir dados");
	mysql_query("INSERT INTO $tabelaPerfil (login,nome,cidade,estado,cep,foto) VALUES ('$c_login','','','','','null')") OR die("Erro ao inserir dados");
	exit;
	}
}
//Lembrar senha
function lembrarSenha($login) 
{
global $tabela,$emailAdmin;
$sql=mysql_query("SELECT login,senha,email
			FROM $tabela
			WHERE login='$login'") or die("Erro ao selecionar dados");
if(!mysql_num_rows($sql)>0)
{
	$m=base64_encode("Esse login n�o est� registrado");
	header("Location: lembrar.php?erro=ok&m=$m");
	exit;
}else{
	$dados=mysql_fetch_array($sql);
	$loginR=$dados['login'];
	$senhaR=$dados['senha'];
	$emailR=$dados['email'];
	$senhaR=base64_decode($senhaR);
	$headers	=	"From: $emailAdmin\n";
	$headers	.=	"Mime-Version: 1.0\nContent-Type: text/html; charset=ISO-8859-1\nContent-Transfer-Encoding: 7bit";
	$mensagem	=	"<font face=\"Tahoma\" size=\"1\">";
	$mensagem	.=	"[Foi feito um pedido para lembrar senha]<br>";
	$mensagem	.=	"Seu login �: $loginR<br>";
	$mensagem	.=	"Sua senha:   $senhaR<br>";
	$mensagem	.=  "E-mail:      $emailR<br>";
	$mensagem	.=	"--------------------------------------------<br>";
	$mensagem	.= 	"</font>";
	echo"<script>javascript:alert('Sua senha foi enviada para o seu e-mail');</script>";
	mail($emailR,"Lembrar senha",$mensagem,$headers);
	}
}
//Direitos no final da p�gina. Favor n�o retirar.
function direitos($autor,$versao,$emailAutor)
{
echo"<font size=\"1\" face=\"Geneva, Arial, Helvetica, sans-serif\" color=\"#000000\"><strong>\n";
echo"Criado por: <a href=\"mailto:$emailAutor\">$autor</a> - Vers�o $versao \n";
echo"</strong></font>\n";
}
?>