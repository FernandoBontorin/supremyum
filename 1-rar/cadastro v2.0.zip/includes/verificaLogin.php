<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
if($_GET['acao']=="logar")
{
if(empty($_POST['login']))
{
	$m=base64_encode("Preencha o seu login");
	header("Location: index.php?erro=ok&m=$m");
	exit;
}
if(empty($_POST['senha']))
{
	$m=base64_encode("Preencha sua senha");
	header("Location: index.php?erro=ok&m=$m");
	exit;
}
$sql=mysql_query("SELECT login,senha FROM $tabela WHERE login='$login'");
if(!mysql_num_rows($sql)>0)
{
	$m=base64_encode("Login n�o encontrado!");
	header("Location: index.php?erro=ok&m=$m");
	exit;
}else{
	$dados=mysql_fetch_array($sql);
	$loginR=$dados['login'];//Pega o login registrado no bd
	$senhaR=$dados['senha'];//Pega a senha registrada no bd
	$senhaR=base64_decode($senhaR);//Descr.
if($_POST['senha']!=$senhaR OR $_POST['login']!=$loginR)
{
	$m=base64_encode("Dados inv�lidos");
	header("Location: index.php?erro=ok&m=$m");
	exit;
}elseif($_POST['senha']==$senhaR AND $_POST['login']==$loginR)
{
	$senha=base64_encode($senha);
	session_start();
	session_register('login');
	session_register('senha');
	header("Location: index2.php");
	exit;
		}
	}
}
?>