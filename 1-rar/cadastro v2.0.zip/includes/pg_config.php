<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006
*/
//Nome da tabela
$tabela		 ="cadastro_usuarios";
$tabelaPerfil="cadastro_perfil";
$keywords	 ="site,cadastro,sistema,cadastro";
$description ="sistema de cadastro para o site 123445656767";
//Conex�o
$bdhost		="localhost";
$bdusuario	="root"; 	
$bdsenha	=""; 				
$bdbanco	="banco"; 	
mysql_connect($bdhost,$bdusuario,$bdsenha);
mysql_select_db($bdbanco);
//Cor dos sub-t�tulos
$corDefinida=	"#000000";
//Dados do admin
$adminLogin	=	"admin";
$adminSenha	=	"admin";
$emailAdmin	=	"email@email.com";
//N�mero de exibi��es por p�gina na area do admin
$pPagina=5;
//Direitos no final da p�gina. Favor n�o retirar.
$autor		=	"Eduardo Stuart";
$versao		=	"2.0";
$emailAutor	=	"stuart.eduardo@gmail.com";

?>