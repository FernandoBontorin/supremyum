<?php
/*
Sistema de cadastro
Autor: Eduardo Stuart
E-mail:stuart.eduardo@gmail.com
http://www.stu.1br.net
Manter os direitos no final de todas as p�ginas
24/09/2006 
ATUALIZACAO: 26/10/2006 
*/
include"includes/pg_fns.php";
include"includes/pg_config.php";
require"includes/verificaLogin.php";
//Verifica se a secao j� existe
session_start();
if(session_is_registered('login') AND session_is_registered('senha'))
{
session_destroy();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<link href="estilos.css" rel="stylesheet" type="text/css">
<? instalaVerifica($acao); ?>
<? pg_Cabecalho("[Login de usu�rios]"); ?>
<body leftmargin="0" rightmargin="0" topmargin="0">
<!-- Come�o da p�gina -->
<? mensagensErro($erro,$m); ?>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td> 
      <? pg_titulos("Login de usu�rios",$corDefinida,"[Digite seus dados para efetuar o login]") ?>
      <br>
      <? menuOpcoes("cadastro.php","[N�o sou cadastrado!]","lembrar.php","[Lembrar senha]"); ?> </td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr> 
    <td>
        <form name="formlogin" method="post" action="<?=$PHP_SELF?>?acao=logar">
          <table width="283" border="0" align="center" cellpadding="2" cellspacing="0">
            <tr> 
              <td width="81"><div align="right"><font size="1" face="tahoma">Login:</font></div></td>
              <td width="194"><input name="login" type="text" class="inputs" id="login"></td>
            </tr>
            <tr> 
              <td><div align="right"><font size="1" face="tahoma">Senha:</font></div></td>
              <td><input name="senha" type="password" class="inputs" id="senha"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><input name="btl" type="submit" id="btl" value="Logar" class="botao"></td>
            </tr>
          </table>
        </form>
        </td>
  </tr>
  <tr> 
    <td></td>
  </tr>
  <tr> 
    <td><hr size="1" color="#CCCCCC" noshade style="border:dotted;"></td>
  </tr>
  <tr>
    <td><center>
        <? direitos($autor,$versao,$emailAutor); ?>
      </center></td>
  </tr>
</table>
<p>
  <!--Fim da p�gina -->
</p>
</body>
</html>
