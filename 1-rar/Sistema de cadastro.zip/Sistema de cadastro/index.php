<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 36px}
-->
</style>
<link href="Config/Sistema_de_Cadastro.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style2 {
	color: #FFFFFF;
	font-weight: bold;
}
.style3 {color: #0000FF}
-->
</style>
</head>

<body>
<form action="logar.php" method="post" enctype="multipart/form-data" name="formlogin">
<table width="631" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="246" height="25">&nbsp;</td>
    <td width="79">&nbsp;</td>
    <td width="24">&nbsp;</td>
    <td width="48">&nbsp;</td>
    <td width="71">&nbsp;</td>
    <td width="25">&nbsp;</td>
    <td width="52">&nbsp;</td>
    <td width="86">&nbsp;</td>
    </tr>
  <tr>
    <td height="46">&nbsp;</td>
    <td colspan="6" valign="top"><span class="style1">Sistema de Cadastro </span></td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td height="35">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    </tr>
  <tr>
    <td height="52">&nbsp;</td>
    <td colspan="5" valign="top"><table width="100%" border="2" bordercolor="#FFFFFF" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="70" height="24" align="right" valign="middle" bgcolor="#000000"><span class="style2">Login:</span></td>
            <td width="169" valign="middle" bgcolor="#CCCCCC"><label for="textfield"></label>
            <input name="login" type="text" id="login" maxlength="200" /></td>
          </tr>
      <tr>
        <td height="24" align="right" valign="middle" bgcolor="#000000" class="style2">Senha:</td>
            <td valign="middle" bgcolor="#CCCCCC"><label for="label"></label>
              <input name="senha" type="password" id="label" maxlength="15" /></td>
          </tr>
      
      
      
      
      
      
    </table></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="24"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td valign="top"><label for="Submit"></label>
      <input type="submit" name="logar" value="Logar" id="logar" /></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="23"></td>
    <td valign="middle"><a href="cadastro.php" class="style3">Cadastre-se</a></td>
    <td>&nbsp;</td>
    <td colspan="2" valign="middle"><a href="Senha/lembrar_senha.php" class="style3">Esqueceu a senha?</a> </td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td height="149"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
    <td></td>
  </tr>
</table>
</form>
</body>
</html>
